# ENTORNO · Redibujo y sistema visual unificado

## Cambios
- Treinta SVG originales sustituidos: quince esquemas de condición y quince comparaciones de problema y rediseño. ViewBox común 960×640, etiquetas amplias y sin textos fuera del marco. Mano de cinco dedos con índice doblado; representación diferente de acúfenos y barotrauma; comparación de cristalino claro/nublado; hueso, tendón y bursa diferenciados; líderes de síntomas; demandas más pesadas en la balanza; distancia de ojo a pantalla.
- Jerarquía reconstruida como cinco niveles contiguos, con clave de nombres y ejemplos originales. Mapa de normas con conexiones y enlaces a fichas. Gráfico de fichas por factor con escala explícita 0–5 y valores 5/5/5.
- CSS sustituido por un sistema coherente: Helvetica, Helvetica Neue, Arial y sans-serif como respaldo; títulos y subtítulos azul marino #0A1F44, texto de lectura negro #000. Negritas para jerarquía. Fondos claros, bordes y márgenes compartidos, lectura móvil apilada.
- Controles anterior/siguiente accesibles siempre, indicación de sección activa y navegación por enlaces/teclado inmediata.
- Transición con resorte críticamente amortiguado, conservando continuidad cuando se cambia rápidamente de página. Animación dentro del marco para evitar desbordamiento; finalización de respaldo en 600 ms si el navegador pierde cuadros. Sin bloqueo de entrada ni contenido oculto por defecto. Animación sutil al abrir justificación y gráficos. Respeta movimiento reducido y hover solo en punteros compatibles.

## Integridad
Exactamente 15 enfermedades. app-data.js intacto byte por byte, verificado con SHA-256. No se añadieron estadísticas clínicas, enfermedades, normas ni referencias.

## Validación
30 SVG renderizados a 1440 px y revisados en hoja de contacto. Sin etiquetas fuera del viewBox.
Chromium, Firefox y WebKit: 658 comprobaciones por motor sobre 40 vistas y cuatro tamaños (1920×1080, 1366×768, 1024×768, 390×844), navegación, filtros, búsqueda, presentación, interrupciones y movimiento reducido. Sin errores de consola JavaScript ni recursos faltantes. Familia tipográfica y colores de lectura/títulos comprobados en las vistas. WebKit en Linux no sustituye Safari nativo.

## Netlify
Descomprime y sube la carpeta que contiene index.html. No requiere compilación ni GitHub. Incluye charts-final.js y charts-final.css, que deben conservarse junto a magazine.js y magazine.css.
