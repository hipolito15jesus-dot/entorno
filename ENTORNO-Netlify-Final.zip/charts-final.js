/* Source-bound charts. All counts and relationships come from CATALOG. */
'use strict';
function rebuildEditorialCharts(data, escapeHtml) {
  const esc = escapeHtml || (value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));
  const groups = [
    {id:'ergonomic', name:'Ergonómicos', norms:[0,1]},
    {id:'physical', name:'Físicos', norms:[2,3,4,5,6]},
    {id:'psychosocial', name:'Psicosociales', norms:[7]}
  ];
  const aliases = {'Dedo en gatillo':'dedo-gatillo','Acúfenos':'tinnitus','Cáncer':'cancer','Cáncer (ultravioleta, infrarrojo)':'cancer'};
  const caseLink = (c, label) => `<a class="chart-case-link" href="#ficha-${esc(c.slug)}">${esc(label || c.title)}</a>`;
  const relationship = label => {
    if (label === 'Todas las psicosociales') return `<span class="chart-relation-label">${esc(label)}</span><div class="chart-case-links">${data.cases.filter(c=>c.group==='psychosocial').map(c=>caseLink(c)).join('')}</div>`;
    if (label === 'Nivel 5 de todas las fichas') return `<span class="chart-relation-label">${esc(label)}</span><details class="chart-all-cases"><summary>Ver las 15 fichas</summary><div class="chart-case-links">${data.cases.map(c=>caseLink(c)).join('')}</div></details>`;
    const c = data.cases.find(c=>c.slug===aliases[label] || c.title===label);
    return c ? caseLink(c,label) : `<span>${esc(label)}</span>`;
  };
  // The broad upper band is elimination; EPP is the final, narrow band.
  // This is an ordinal illustration, never a numerical estimate of effectiveness.
  const x = [44,100,156,212,268,324], y = [20,96,172,248,324,400];
  const bands = data.hierarchy.map((h,i)=>{
    const leftTop=x[i], rightTop=756-x[i], leftBottom=x[i+1], rightBottom=756-x[i+1];
    return `<path d="M${leftTop} ${y[i]}H${rightTop}L${rightBottom} ${y[i+1]}H${leftBottom}Z" class="chart-pyramid-band chart-pyramid-band-${i+1}"/><text x="378" y="${y[i]+46}" text-anchor="middle">${i+1}</text>`;
  }).join('');
  const hierarchy = `<div class="chart-hierarchy"><figure class="chart-pyramid"><svg viewBox="0 0 756 420" role="img" aria-labelledby="chart-pyramid-title chart-pyramid-desc"><title id="chart-pyramid-title">Jerarquía de controles: cinco niveles</title><desc id="chart-pyramid-desc">De arriba hacia abajo: ${data.hierarchy.map((h,i)=>`${i+1}, ${esc(h.name)}`).join('; ')}.</desc>${bands}</svg><figcaption><div class="chart-pyramid-key">${data.hierarchy.map((h,i)=>`<span><b>${i+1}</b> ${esc(h.name)}</span>`).join('')}</div></figcaption></figure><ol class="chart-control-list">${data.hierarchy.map((h,i)=>`<li><span class="chart-control-index" aria-hidden="true">${i+1}</span><div><h3>${esc(h.name)}</h3><p>${esc(h.meaning)}</p><p class="chart-example">${esc(h.example)}</p></div></li>`).join('')}</ol></div>`;
  const normRow = norm => `<article class="chart-norm"><h4>${esc(norm.code)}</h4><p class="chart-norm-topic">${esc(norm.topic)}</p><div class="chart-norm-cases">${norm.usedIn.map(relationship).join('')}</div></article>`;
  const normMap = `<div class="chart-norm-map">${groups.map(g=>`<section class="chart-factor-block"><div class="chart-factor-heading"><span aria-hidden="true">${String(groups.indexOf(g)+1).padStart(2,'0')}</span><h3><a href="#grupo-${g.id}">${g.name}</a></h3></div><div class="chart-factor-norms">${g.norms.map(i=>normRow(data.norms[i])).join('')}</div></section>`).join('')}<section class="chart-factor-block chart-shared-control"><div class="chart-factor-heading"><span aria-hidden="true">+</span><h3>Complemento de protección</h3></div>${normRow(data.norms[8])}</section></div>`;
  const counts = groups.map(g=>({...g,count:data.cases.filter(c=>c.group===g.id).length}));
  const maxCount = Math.max(...counts.map(g=>g.count),1);
  const ticks = Array.from({length:maxCount+1},(_,i)=>i);
  const distribution = `<figure class="chart-distribution" aria-labelledby="chart-distribution-title"><figcaption id="chart-distribution-title">Fichas por factor</figcaption><div class="chart-distribution-unit">Número de fichas</div><div class="chart-bar-grid">${counts.map(g=>`<a class="chart-bar-row" href="#grupo-${g.id}" aria-label="${g.name}: ${g.count} fichas"><span class="chart-bar-label">${g.name}</span><span class="chart-bar-track" style="--chart-divisions:${maxCount}"><span class="chart-bar-fill" style="width:${g.count/maxCount*100}%"></span></span><strong>${g.count}</strong></a>`).join('')}<div class="chart-bar-axis" aria-hidden="true"><span></span><div>${ticks.map(t=>`<span>${t}</span>`).join('')}</div><span></span></div></div><p class="chart-total"><strong>${data.cases.length}</strong> fichas en el catálogo</p></figure>`;
  return {hierarchy,normMap,distribution};
}
